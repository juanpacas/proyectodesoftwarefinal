const express = require('express');
const PocketBase = require('pocketbase/cjs');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const pb = new PocketBase('http://148.116.64.112:8090');

app.get('/api/barberos', async (req, res) => {
    try {
        const records = await pb.collection('barberos').getFullList();
        res.json(records);
    } catch (error) {
        res.status(500).json({ error: 'Error conexion PocketBase' });
    }
});

app.listen(3001, () => console.log('Servidor corriendo'));

app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const authData = await pb.collection('usuarios').authWithPassword(email, password);
        res.json({ success: true, user: authData.record });
    } catch (error) {
        res.status(401).json({ success: false, message: 'Falla en autenticación' });
    }
});
import React, { useEffect, useState } from 'react';

function App() {
  const [barberos, setBarberos] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/api/barberos')
      .then(response => response.json())
      .then(data => setBarberos(data))
      .catch(error => console.error('Error:', error));
  }, []);

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Barberos Disponibles</h1>
      <p style={styles.subtitle}>Selecciona el experto de tu confianza</p>
      
      <div style={styles.list}>
        {barberos.map(barbero => (
          <div key={barbero.id} style={styles.card}>
            <div style={styles.imageContainer}>
              {/* Aquí usamos el icono de tu diseño */}
              <img src="https://cdn-icons-png.flaticon.com/512/147/147144.png" alt="barbero" style={styles.avatar} />
            </div>
            <div style={styles.info}>
              <h3 style={styles.name}>{barbero.nombre}</h3>
              <p style={styles.specialty}>{barbero.especialidad}</p>
              <p style={styles.location}>{barbero.direccion || 'Bogotá, Colombia'}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  container: { padding: '40px 20px', backgroundColor: '#fff', minHeight: '100vh' },
  title: { fontSize: '28px', fontWeight: 'bold', color: '#1a1a1a', marginBottom: '5px' },
  subtitle: { color: '#666', marginBottom: '30px' },
  list: { display: 'flex', flexDirection: 'column', gap: '20px' },
  card: {
    display: 'flex',
    padding: '15px',
    borderRadius: '20px',
    backgroundColor: '#fff',
    boxShadow: '0px 4px 15px rgba(0,0,0,0.05)',
    borderLeft: '4px solid #b71c1c', // El borde rojo de tu diseño
    alignItems: 'center'
  },
  imageContainer: { backgroundColor: '#f5f5f5', borderRadius: '12px', padding: '10px', marginRight: '15px' },
  avatar: { width: '50px', height: '50px' },
  name: { margin: 0, fontSize: '18px', color: '#333' },
  specialty: { margin: '2px 0', color: '#777', fontSize: '14px' },
  location: { margin: 0, color: '#444', fontSize: '13px' }
};

export default App;